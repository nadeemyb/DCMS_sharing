import pandas as pd
import matplotlib.pyplot as plt

data = {
    "Consensus": [
        "QBFT", "QBFT", "QBFT",
        "IBFT2", "IBFT2", "IBFT2",
        "Clique", "Clique", "Clique"
    ],
    "Scenario": [
        "Normal", "Delegate", "Emergency",
        "Normal", "Delegate", "Emergency",
        "Normal", "Delegate", "Emergency"
    ],
    "Avg Latency (s)": [
        4.9175, 4.9523, 4.9553,      # QBFT
        9.7350, 9.9583, 9.5675,      # IBFT2
        9.7405, 9.9657, 9.5699       # Clique
    ]
}

df = pd.DataFrame(data)

fig, ax = plt.subplots(figsize=(10, 6))

width = 0.25
scenarios = ["Normal", "Delegate", "Emergency"]
x = range(len(scenarios))

for i, consensus in enumerate(df["Consensus"].unique()):
    subset = df[df["Consensus"] == consensus]
    ax.bar([p + i * width for p in x],
           subset["Avg Latency (s)"],
           width=width,
           label=consensus)

ax.set_xticks([p + width for p in x])
ax.set_xticklabels(scenarios)
ax.set_xlabel("PBAC Scenario")
ax.set_ylabel("Average Latency (s)")
ax.set_title("Average Latency by Consensus Mechanism and PBAC Scenario")
ax.legend()

plt.tight_layout()
plt.show()