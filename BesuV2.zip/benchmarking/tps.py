import pandas as pd
import matplotlib.pyplot as plt

data = {
    "Consensus": [
        "QBFT", "QBFT", "QBFT",
        "IBFT2", "IBFT2", "IBFT2",
        "Clique", "Clique", "Clique"
    ],
    "Scenario": [
        "Normal", "Delegate", "Emergency",
        "Normal", "Delegate", "Emergency",
        "Normal", "Delegate", "Emergency"
    ],
    "TPS": [
        0.1783, 0.1783, 0.1783,   # QBFT
        0.0943, 0.0943, 0.0943,   # IBFT2
        0.0934, 0.0917, 0.0929    # Clique
    ]
}

df = pd.DataFrame(data)

fig, ax = plt.subplots(figsize=(10, 6))

width = 0.25
scenarios = ["Normal", "Delegate", "Emergency"]
x = range(len(scenarios))

for i, consensus in enumerate(df["Consensus"].unique()):
    subset = df[df["Consensus"] == consensus]
    ax.bar([p + i * width for p in x],
           subset["TPS"],
           width=width,
           label=consensus)

ax.set_xticks([p + width for p in x])
ax.set_xticklabels(scenarios)
ax.set_xlabel("PBAC Scenario")
ax.set_ylabel("Workflow TPS")
ax.set_title("Workflow TPS by Consensus Mechanism and PBAC Scenario")
ax.legend()

plt.tight_layout()
plt.show()