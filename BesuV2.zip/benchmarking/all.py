import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

data = {
    "Consensus": ["QBFT", "QBFT", "QBFT",
                  "IBFT2", "IBFT2", "IBFT2",
                  "Clique", "Clique", "Clique"],
    "Scenario": ["Normal", "Delegate", "Emergency",
                 "Normal", "Delegate", "Emergency",
                 "Clique", "Clique", "Clique"],
    "CPU Usage": [10.02, 9.21, 9.29, 9.88, 9.31, 8.92, 2.20, 2.31, 2.16],
    "Memory Usage": [6359.46, 6381.33, 6380.53, 5497.31, 5482.98, 5471.02, 5837.90, 5841.10, 5843.52],
    "Gas Usage": [4578315, 1752915, 2257265, 4578315, 1752915, 2257265, 4578315, 1752915, 2257265]
}

df = pd.DataFrame(data)

# Fix scenario names for Clique rows
df.loc[df["Consensus"] == "Clique", "Scenario"] = ["Normal", "Delegate", "Emergency"]

fig, axes = plt.subplots(3, 1, figsize=(10, 12), sharex=True)

metrics = ["CPU Usage", "Memory Usage", "Gas Usage"]
consensus_list = ["QBFT", "IBFT2", "Clique"]
scenarios = ["Normal", "Delegate", "Emergency"]

x = np.arange(len(scenarios))
bar_width = 0.25

for ax, metric in zip(axes, metrics):
    for i, consensus in enumerate(consensus_list):
        subset = df[df["Consensus"] == consensus]
        ax.bar(
            x + i * bar_width,
            subset[metric],
            width=bar_width,
            label=consensus if metric == "CPU Usage" else ""
        )

    ax.set_ylabel(metric)

axes[-1].set_xticks(x + bar_width)
axes[-1].set_xticklabels(scenarios)
axes[-1].set_xlabel("PBAC Scenario")

axes[0].legend()

plt.tight_layout()
plt.show()