import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

data = {
    "Consensus": [
        "QBFT", "QBFT", "QBFT",
        "IBFT2", "IBFT2", "IBFT2",
        "Clique", "Clique", "Clique"
    ],
    "Scenario": [
        "Normal", "Delegate", "Emergency",
        "Normal", "Delegate", "Emergency",
        "Normal", "Delegate", "Emergency"
    ],
    "Time (s)": [
        132.77, 54.48, 64.42,      # QBFT
        262.85, 109.54, 124.38,    # IBFT2
        289.06, 119.98, 139.95     # Clique
    ]
}

df = pd.DataFrame(data)

fig, ax = plt.subplots(figsize=(10, 6))

width = 0.25
scenarios = ["Normal", "Delegate", "Emergency"]
x = np.arange(len(scenarios))

for i, consensus in enumerate(["QBFT", "IBFT2", "Clique"]):
    subset = df[df["Consensus"] == consensus]
    ax.bar(
        x + i * width,
        subset["Time (s)"],
        width=width,
        label=consensus
    )

ax.set_xticks(x + width)
ax.set_xticklabels(scenarios)
ax.set_xlabel("PBAC Scenario")
ax.set_ylabel("Scenario Time (s)")
ax.legend()

plt.tight_layout()
plt.show()