"""
T cases: Normal PBAC policy lifecycle tests.

Covers:
T1 Consent true -> Granted
T2 Consent withdrawal -> Pending/Denied
T3 Consent restored -> Granted
T4 Policy revoked -> Denied
T5 Expired policy -> Denied
T6 Wrong purpose -> Denied
T7 Excessive access level -> Denied
T8 Replay requestId attempt -> blocked/policy-bound
"""
import time
import random


def choose_target(core, results):
    for r in results:
        if r.get("success") and r.get("status") == core.V5_TARGET_STATUS and r.get("authorized_cid"):
            return r
    return None


def make_request_id(label_suffix=0):
    return int(time.time()) + random.randint(200001, 999999) + label_suffix


def run_single_request_check(core, patient_id, diagnosis, purpose, access_level, request_id, metrics, label):
    print(f"\n🔎 T Case Request: {label}")
    print(f"• patientId: {patient_id}")
    print(f"• purpose: {purpose}")
    print(f"• access: {access_level}")
    print(f"• requestId: {request_id}")

    submitted = core.submit_access_request(patient_id, diagnosis, purpose, access_level, request_id, metrics)
    if not submitted:
        return {
            "request_submitted": False,
            "decision_evaluated": False,
            "status": "SubmissionFailed",
            "reason": "Access request transaction failed",
            "authorized_cid": "",
            "authorized_hash": "",
        }

    evaluated = core.evaluate_request(request_id, metrics)
    if not evaluated:
        return {
            "request_submitted": True,
            "decision_evaluated": False,
            "status": "EvaluationFailed",
            "reason": "Decision evaluation transaction failed",
            "authorized_cid": "",
            "authorized_hash": "",
        }

    status = core.check_status(request_id, retrieve_ipfs=core.RETRIEVE_GRANTED_IPFS, metrics=metrics)
    if not status:
        return {
            "request_submitted": True,
            "decision_evaluated": True,
            "status": "StatusCheckFailed",
            "reason": "Could not read status",
            "authorized_cid": "",
            "authorized_hash": "",
        }

    print(f"• Result status: {status['status']}")
    print(f"• Result reason: {status['reason']}")
    print(f"• CID: {status['authorized_cid'] if status['authorized_cid'] else 'Restricted'}")

    status["request_submitted"] = True
    status["decision_evaluated"] = True
    return status


def create_normal_policy(core, patient_id, access, purpose, duration, consent, metrics, label):
    print(f"\n🧾 Creating T-case Normal policy for: {label}")
    return core.create_policy(
        patient_id=patient_id,
        kind="Normal",
        access=access,
        purpose=purpose,
        duration=duration,
        consent=consent,
        creator_role="patient",
        metrics=metrics
    )


def append_result(results, test_name, description, policy_id, request_id, policy_snapshot,
                  status, expected_statuses, expected_reasons):
    actual_status = status.get("status", "Unknown")
    actual_reason = status.get("reason", "Unknown")
    cid_returned = bool(status.get("authorized_cid"))
    passed = actual_status in expected_statuses and actual_reason in expected_reasons

    record = {
        "test_name": test_name,
        "scenario": "Normal",
        "description": description,
        "policy_id": policy_id,
        "request_id": request_id,
        "policy": policy_snapshot,
        "actual_status": actual_status,
        "actual_reason": actual_reason,
        "expected_statuses": expected_statuses,
        "expected_reasons": expected_reasons,
        "cid_returned": cid_returned,
        "authorized_cid": status.get("authorized_cid", ""),
        "authorized_hash": status.get("authorized_hash", ""),
        "passed": passed,
    }
    results.append(record)

    print("\n✅ T Case Passed" if passed else "\n❌ T Case Failed")
    print(f"• Test: {test_name}")
    print(f"• Expected status: {expected_statuses}")
    print(f"• Actual status: {actual_status}")
    print(f"• Expected reason: {expected_reasons}")
    print(f"• Actual reason: {actual_reason}")
    print(f"• CID returned: {cid_returned}")


def print_summary(t_results):
    total = len(t_results)
    passed = sum(1 for r in t_results if r.get("passed"))
    cid_returned = sum(1 for r in t_results if r.get("cid_returned"))

    status_counts, reason_counts = {}, {}
    for r in t_results:
        status_counts[r.get("actual_status", "Unknown")] = status_counts.get(r.get("actual_status", "Unknown"), 0) + 1
        reason_counts[r.get("actual_reason", "Unknown")] = reason_counts.get(r.get("actual_reason", "Unknown"), 0) + 1

    print(f"\n{'='*90}")
    print("T CASES: NORMAL POLICY LIFECYCLE SUMMARY")
    print(f"{'='*90}")
    print(f"• Total T cases: {total}")
    print(f"• Passed expected logic: {passed}/{total}")
    print(f"• CIDs returned: {cid_returned}")
    print(f"• CIDs restricted/blocked: {total - cid_returned}")

    print("\nStatus distribution:")
    for status, count in status_counts.items():
        print(f"• {status}: {count}")

    print("\nReason distribution:")
    for reason, count in reason_counts.items():
        print(f"• {reason}: {count}")

    print(f"{'='*90}")


def save_results(core, t_results):
    with open(core.V5_RESULTS_FILE, "w") as f:
        import json
        json.dump(t_results, f, indent=2, default=str)
    print(f"\n✅ T-case results saved: {core.V5_RESULTS_FILE}")


def run_t_cases(core, results, metrics):
    print(f"\n{'#'*90}")
    print("T CASES: NORMAL POLICY LIFECYCLE TESTS")
    print(f"{'#'*90}")

    target = choose_target(core, results)
    if not target:
        print("❌ No clean Granted patient found for T cases.")
        return []

    patient_id = target["patient_id"]
    diagnosis = target["diagnosis"]

    print("\n🎯 T-case target patient selected")
    print(f"• rawPatientId: {target.get('raw_patient_id')}")
    print(f"• contractPatientId: {patient_id}")
    print(f"• diagnosis: {diagnosis}")
    print(f"• baseline policyId: {target.get('policy_id')}")
    print(f"• baseline status: {target.get('status')}")
    print(f"• baseline CID: {target.get('authorized_cid')}")

    t_results = []

    tests = [
        ("T1 Consent true grants access", "Full", "Research", 2592000, True, None, "Research", "Full",
         ["Granted"], ["None"], "Consent is true and requester purpose/access match the policy."),
        ("T2 Consent withdrawal blocks subsequent access", "Full", "Research", 2592000, True, "withdraw", "Research", "Full",
         ["Pending", "Denied"], ["NeedApproval", "ConsentNotGranted"], "Patient withdraws consent; next call should not receive CID."),
        ("T3 Consent restored grants access again", "Full", "Research", 2592000, False, "restore", "Research", "Full",
         ["Granted"], ["None"], "Patient restores consent; matching request should regain CID."),
        ("T4 Policy revocation blocks access", "Full", "Research", 2592000, True, "revoke", "Research", "Full",
         ["Denied"], ["PolicyRevoked", "PolicyInactive", "PolicyDisabled", "NoActivePolicy"], "Patient revokes/deactivates policy."),
        ("T6 Wrong purpose is denied", "Full", "Research", 2592000, True, None, "Marketing", "Full",
         ["Denied"], ["PurposeMismatch"], "Policy allows Research, but requester asks Marketing."),
        ("T7 Excessive access level is denied", "Partial", "Research", 2592000, True, None, "Research", "Full",
         ["Denied"], ["AccessLevelTooHigh"], "Policy allows Partial, but requester asks Full."),
    ]

    for idx, (test_name, pol_access, pol_purpose, duration, consent, action, req_purpose, req_access,
              exp_status, exp_reason, description) in enumerate(tests, start=1):
        created, policy_id = create_normal_policy(core, patient_id, pol_access, pol_purpose, duration, consent, metrics, test_name)
        if not created:
            continue

        if action == "withdraw":
            core.update_consent(policy_id, False, metrics, sender_role="patient")
            consent = False
        elif action == "restore":
            core.update_consent(policy_id, True, metrics, sender_role="patient")
            consent = True
        elif action == "revoke":
            core.revoke_policy(policy_id, metrics, sender_role="patient")

        request_id = make_request_id(idx)
        status = run_single_request_check(core, patient_id, diagnosis, req_purpose, req_access, request_id, metrics, test_name)

        policy_snapshot = {
            "kind": "Normal",
            "access": pol_access,
            "purpose": pol_purpose,
            "duration": duration,
            "consent": consent,
            "post_creation_action": action,
            "request_purpose": req_purpose,
            "request_access": req_access,
        }

        append_result(t_results, test_name, description, policy_id, request_id,
                      policy_snapshot, status, exp_status, exp_reason)

    # T5 expiry case
    test_name = "T5 Expired consent duration blocks access"
    created, policy_id = create_normal_policy(core, patient_id, "Full", "Research",
                                               core.V5_EXPIRED_POLICY_DURATION_SECONDS, True, metrics, test_name)
    if created:
        print(f"\n⏳ Waiting {core.V5_EXPIRED_POLICY_WAIT_SECONDS}s so policy duration expires...")
        time.sleep(core.V5_EXPIRED_POLICY_WAIT_SECONDS)
        request_id = make_request_id(5)
        status = run_single_request_check(core, patient_id, diagnosis, "Research", "Full", request_id, metrics, test_name)
        append_result(t_results, test_name, "Policy duration has expired.", policy_id, request_id,
                      {"kind": "Normal", "access": "Full", "purpose": "Research",
                       "duration": core.V5_EXPIRED_POLICY_DURATION_SECONDS, "consent": True},
                      status, ["Denied"], ["PolicyExpired"])

    # T8 replay case
    if core.V5_TEST_REPLAY_ATTEMPT:
        test_name = "T8 Replay requestId attempt does not bypass policy"
        created, policy_id = create_normal_policy(core, patient_id, "Full", "Research", 2592000, True, metrics, test_name)
        if created:
            replay_request_id = make_request_id(8)
            first_status = run_single_request_check(core, patient_id, diagnosis, "Research", "Full",
                                                    replay_request_id, metrics, test_name + " - first request")
            print("\n🔁 T8 Replay Attempt: submitting the SAME requestId again")
            replay_submit_success = core.submit_access_request(patient_id, diagnosis, "Research", "Full",
                                                               replay_request_id, metrics)
            if replay_submit_success:
                core.evaluate_request(replay_request_id, metrics)
                replay_status = core.check_status(replay_request_id, retrieve_ipfs=core.RETRIEVE_GRANTED_IPFS, metrics=metrics)
                actual_status = replay_status.get("status", "Unknown") if replay_status else "StatusCheckFailed"
                actual_reason = replay_status.get("reason", "Unknown") if replay_status else "Unknown"
                replay_cid = replay_status.get("authorized_cid", "") if replay_status else ""
                passed = actual_status in ["Granted", "Denied", "Pending", "PartialGranted"]
                interpretation = "Replay accepted but did not bypass policy; status remained policy-bound"
            else:
                actual_status = "SubmissionFailed"
                actual_reason = "ReplayBlocked"
                replay_cid = ""
                passed = True
                interpretation = "Duplicate requestId/replay transaction was blocked"

            record = {
                "test_name": test_name,
                "scenario": "Normal",
                "description": "Same requestId is submitted twice to test replay/duplicate-request behavior.",
                "policy_id": policy_id,
                "request_id": replay_request_id,
                "first_request_status": first_status.get("status", "Unknown"),
                "first_request_reason": first_status.get("reason", "Unknown"),
                "replay_submit_success": replay_submit_success,
                "actual_status": actual_status,
                "actual_reason": actual_reason,
                "expected_statuses": ["SubmissionFailed", "Granted", "Denied", "Pending", "PartialGranted"],
                "expected_reasons": ["ReplayBlocked", "None", "PurposeMismatch", "AccessLevelTooHigh", "NeedApproval"],
                "cid_returned": bool(replay_cid),
                "authorized_cid": replay_cid,
                "passed": passed,
                "interpretation": interpretation,
            }
            t_results.append(record)
            print("\n✅ T8 Replay Test Passed" if passed else "\n❌ T8 Replay Test Failed")

    print_summary(t_results)
    save_results(core, t_results)
    return t_results
