"""
D cases: Delegate PBAC authorization tests.

Covers:
D1-D2 valid delegate policy grants matching access
D3 delegate consent withdrawal blocks access
D4 unauthorized delegate policy creation is blocked
D5 delegate policy revocation blocks access
"""
import time
import random
from t_cases import run_single_request_check


def choose_target(core, results):
    for r in results:
        if r.get("success") and r.get("status") == core.V6_TARGET_STATUS and r.get("authorized_cid"):
            return r
    return None


def make_request_id(label_suffix=0):
    return int(time.time()) + random.randint(300001, 999999) + label_suffix


def create_delegate_policy(core, patient_id, access, purpose, duration, consent, creator_role, metrics, label):
    print(f"\n🧾 Creating D-case Delegate policy for: {label}")
    print(f"• creator_role: {creator_role}")
    print(f"• access: {access}")
    print(f"• purpose: {purpose}")
    return core.create_policy(patient_id, "Delegate", access, purpose, duration, consent, creator_role, metrics)


def append_result(d_results, test_name, description, policy_id, request_id,
                  actual_status, actual_reason, cid_returned, expected_statuses,
                  expected_reasons, passed=None, extra=None):
    if passed is None:
        passed = actual_status in expected_statuses and actual_reason in expected_reasons
    record = {
        "test_name": test_name,
        "scenario": "Delegate",
        "description": description,
        "policy_id": policy_id,
        "request_id": request_id,
        "actual_status": actual_status,
        "actual_reason": actual_reason,
        "expected_statuses": expected_statuses,
        "expected_reasons": expected_reasons,
        "cid_returned": cid_returned,
        "passed": passed,
    }
    if extra:
        record.update(extra)
    d_results.append(record)

    print("\n✅ D Case Passed" if passed else "\n❌ D Case Failed")
    print(f"• Test: {test_name}")
    print(f"• Actual status: {actual_status}")
    print(f"• Actual reason: {actual_reason}")
    print(f"• CID returned: {cid_returned}")


def run_status_test(core, d_results, test_name, description, policy_id, patient_id,
                    diagnosis, purpose, access, metrics, expected_statuses,
                    expected_reasons, label_suffix):
    request_id = make_request_id(label_suffix)
    status = run_single_request_check(core, patient_id, diagnosis, purpose, access, request_id, metrics, f"Delegate - {test_name}")
    append_result(
        d_results, test_name, description, policy_id, request_id,
        status.get("status", "Unknown"),
        status.get("reason", "Unknown"),
        bool(status.get("authorized_cid")),
        expected_statuses, expected_reasons,
        extra={
            "authorized_cid": status.get("authorized_cid", ""),
            "authorized_hash": status.get("authorized_hash", ""),
            "request_purpose": purpose,
            "request_access": access,
        }
    )


def print_summary(d_results):
    total = len(d_results)
    passed = sum(1 for r in d_results if r.get("passed"))
    cid_returned = sum(1 for r in d_results if r.get("cid_returned"))
    print(f"\n{'='*90}")
    print("D CASES: DELEGATE AUTHORIZATION SUMMARY")
    print(f"{'='*90}")
    print(f"• Total D cases: {total}")
    print(f"• Passed expected logic: {passed}/{total}")
    print(f"• CIDs returned: {cid_returned}")
    print(f"• CIDs restricted/blocked: {total - cid_returned}")
    print(f"{'='*90}")


def run_d_cases(core, results, metrics):
    print(f"\n{'#'*90}")
    print("D CASES: DELEGATE AUTHORIZATION TESTS")
    print(f"{'#'*90}")

    target = choose_target(core, results)
    if not target:
        print("❌ No clean Granted patient found for D cases.")
        return []

    patient_id = target["patient_id"]
    diagnosis = target["diagnosis"]
    d_results = []

    # D1-D2
    test_name = "D1-D2 Valid delegate policy grants matching access"
    created, policy_id = create_delegate_policy(core, patient_id, core.V6_DELEGATE_ACCESS,
                                                 core.V6_DELEGATE_PURPOSE, 2592000, True,
                                                 "delegate", metrics, test_name)
    if created:
        expected_statuses = ["PartialGranted"] if core.V6_DELEGATE_ACCESS == "Partial" else ["Granted"]
        run_status_test(core, d_results, test_name,
                        "Authorized delegate creates a Delegate policy; requester asks matching purpose/access.",
                        policy_id, patient_id, diagnosis, core.V6_DELEGATE_PURPOSE,
                        core.V6_DELEGATE_ACCESS, metrics, expected_statuses, ["None"], 101)

    # D3
    test_name = "D3 Delegate consent withdrawal blocks access"
    created, policy_id = create_delegate_policy(core, patient_id, "Full", core.V6_DELEGATE_PURPOSE,
                                                 2592000, True, "delegate", metrics, test_name)
    if created:
        core.update_consent(policy_id, False, metrics, sender_role="delegate")
        run_status_test(core, d_results, test_name,
                        "Authorized delegate changes consent to false; next requester call should not receive CID.",
                        policy_id, patient_id, diagnosis, core.V6_DELEGATE_PURPOSE, "Full",
                        metrics, ["Pending", "Denied"], ["NeedApproval", "ConsentNotGranted"], 102)

    # D4
    test_name = "D4 Unauthorized delegate policy creation is blocked"
    print(f"\n🧪 D-case Delegate Misuse Test: {test_name}")
    created, bad_policy_id = core.create_policy(patient_id, "Delegate", "Full",
                                                core.V6_DELEGATE_PURPOSE, 2592000, True,
                                                "requester", metrics)
    if created:
        append_result(d_results, test_name,
                      "Requester attempted to create a Delegate policy without being the registered delegate.",
                      bad_policy_id, None, "PolicyCreated", "UnauthorizedDelegateAccepted",
                      False, ["SubmissionFailed", "TransactionReverted"],
                      ["UnauthorizedDelegateBlocked"], passed=False)
    else:
        append_result(d_results, test_name,
                      "Requester attempted to create a Delegate policy without being the registered delegate.",
                      None, None, "SubmissionFailed", "UnauthorizedDelegateBlocked",
                      False, ["SubmissionFailed", "TransactionReverted"],
                      ["UnauthorizedDelegateBlocked"], passed=True)

    # D5
    test_name = "D5 Delegate policy revocation blocks access"
    created, policy_id = create_delegate_policy(core, patient_id, "Full", core.V6_DELEGATE_PURPOSE,
                                                 2592000, True, "delegate", metrics, test_name)
    if created:
        core.revoke_policy(policy_id, metrics, sender_role="delegate")
        run_status_test(core, d_results, test_name,
                        "Authorized delegate revokes Delegate policy; later requester call should be denied/restricted.",
                        policy_id, patient_id, diagnosis, core.V6_DELEGATE_PURPOSE, "Full",
                        metrics, ["Denied"], ["PolicyRevoked", "PolicyInactive", "PolicyDisabled", "NoActivePolicy"], 103)

    print_summary(d_results)
    return d_results
