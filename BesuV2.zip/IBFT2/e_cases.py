"""
E cases: Emergency PBAC authorization tests.

Covers:
E1-E2 controller emergency policy grants emergency access
E3 wrong emergency purpose is denied
E4 emergency policy expiry blocks access
E5 emergency policy revocation blocks access
"""
import time
import random
from t_cases import run_single_request_check


def choose_target(core, results):
    for r in results:
        if r.get("success") and r.get("status") == core.V6_TARGET_STATUS and r.get("authorized_cid"):
            return r
    return None


def make_request_id(label_suffix=0):
    return int(time.time()) + random.randint(400001, 999999) + label_suffix


def create_emergency_policy(core, patient_id, access, purpose, duration, consent, metrics, label):
    print(f"\n🧾 Creating E-case Emergency policy for: {label}")
    print(f"• creator_role: controller")
    print(f"• access: {access}")
    print(f"• purpose: {purpose}")
    return core.create_policy(patient_id, "Emergency", access, purpose, duration, consent, "controller", metrics)


def append_result(e_results, test_name, description, policy_id, request_id,
                  actual_status, actual_reason, cid_returned, expected_statuses,
                  expected_reasons, extra=None):
    passed = actual_status in expected_statuses and actual_reason in expected_reasons
    record = {
        "test_name": test_name,
        "scenario": "Emergency",
        "description": description,
        "policy_id": policy_id,
        "request_id": request_id,
        "actual_status": actual_status,
        "actual_reason": actual_reason,
        "expected_statuses": expected_statuses,
        "expected_reasons": expected_reasons,
        "cid_returned": cid_returned,
        "passed": passed,
    }
    if extra:
        record.update(extra)
    e_results.append(record)

    print("\n✅ E Case Passed" if passed else "\n❌ E Case Failed")
    print(f"• Test: {test_name}")
    print(f"• Actual status: {actual_status}")
    print(f"• Actual reason: {actual_reason}")
    print(f"• CID returned: {cid_returned}")


def run_status_test(core, e_results, test_name, description, policy_id, patient_id,
                    diagnosis, purpose, access, metrics, expected_statuses,
                    expected_reasons, label_suffix):
    request_id = make_request_id(label_suffix)
    status = run_single_request_check(core, patient_id, diagnosis, purpose, access, request_id, metrics, f"Emergency - {test_name}")
    append_result(
        e_results, test_name, description, policy_id, request_id,
        status.get("status", "Unknown"),
        status.get("reason", "Unknown"),
        bool(status.get("authorized_cid")),
        expected_statuses, expected_reasons,
        extra={
            "authorized_cid": status.get("authorized_cid", ""),
            "authorized_hash": status.get("authorized_hash", ""),
            "request_purpose": purpose,
            "request_access": access,
        }
    )


def print_summary(e_results):
    total = len(e_results)
    passed = sum(1 for r in e_results if r.get("passed"))
    cid_returned = sum(1 for r in e_results if r.get("cid_returned"))
    print(f"\n{'='*90}")
    print("E CASES: EMERGENCY AUTHORIZATION SUMMARY")
    print(f"{'='*90}")
    print(f"• Total E cases: {total}")
    print(f"• Passed expected logic: {passed}/{total}")
    print(f"• CIDs returned: {cid_returned}")
    print(f"• CIDs restricted/blocked: {total - cid_returned}")
    print(f"{'='*90}")


def run_e_cases(core, results, metrics):
    print(f"\n{'#'*90}")
    print("E CASES: EMERGENCY AUTHORIZATION TESTS")
    print(f"{'#'*90}")

    target = choose_target(core, results)
    if not target:
        print("❌ No clean Granted patient found for E cases.")
        return []

    patient_id = target["patient_id"]
    diagnosis = target["diagnosis"]
    e_results = []

    # E1-E2
    test_name = "E1-E2 Controller emergency policy grants emergency access"
    created, policy_id = create_emergency_policy(core, patient_id, core.V6_EMERGENCY_ACCESS,
                                                  core.V6_EMERGENCY_PURPOSE, 2592000, True,
                                                  metrics, test_name)
    if created:
        run_status_test(core, e_results, test_name,
                        "Controller creates Emergency policy; requester asks EmergencyCare with allowed access.",
                        policy_id, patient_id, diagnosis, core.V6_EMERGENCY_PURPOSE,
                        core.V6_EMERGENCY_ACCESS, metrics, ["Granted"], ["None"], 201)

    # E3
    test_name = "E3 Wrong emergency purpose is denied"
    created, policy_id = create_emergency_policy(core, patient_id, "Full", core.V6_EMERGENCY_PURPOSE,
                                                  2592000, True, metrics, test_name)
    if created:
        run_status_test(core, e_results, test_name,
                        "Emergency policy allows EmergencyCare, but requester asks Research.",
                        policy_id, patient_id, diagnosis, "Research", "Full",
                        metrics, ["Denied"], ["PurposeMismatch"], 202)

    # E4
    test_name = "E4 Emergency policy expiry blocks access"
    created, policy_id = create_emergency_policy(core, patient_id, "Full", core.V6_EMERGENCY_PURPOSE,
                                                  core.V6_EMERGENCY_DURATION_SECONDS, True,
                                                  metrics, test_name)
    if created:
        print(f"\n⏳ Waiting {core.V6_EMERGENCY_WAIT_SECONDS}s so emergency policy expires...")
        time.sleep(core.V6_EMERGENCY_WAIT_SECONDS)
        run_status_test(core, e_results, test_name,
                        "Emergency policy is time-limited; after expiry, requester access should be denied.",
                        policy_id, patient_id, diagnosis, core.V6_EMERGENCY_PURPOSE, "Full",
                        metrics, ["Denied"], ["PolicyExpired"], 203)

    # E5
    test_name = "E5 Emergency policy revocation blocks access"
    created, policy_id = create_emergency_policy(core, patient_id, "Full", core.V6_EMERGENCY_PURPOSE,
                                                  2592000, True, metrics, test_name)
    if created:
        core.revoke_policy(policy_id, metrics, sender_role="controller")
        run_status_test(core, e_results, test_name,
                        "Controller revokes Emergency policy; later requester call should be denied/restricted.",
                        policy_id, patient_id, diagnosis, core.V6_EMERGENCY_PURPOSE, "Full",
                        metrics, ["Denied"], ["PolicyRevoked", "PolicyInactive", "PolicyDisabled", "NoActivePolicy"], 204)

    print_summary(e_results)
    return e_results
