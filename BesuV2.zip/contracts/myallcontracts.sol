// SPDX-License-Identifier: MIT
pragma solidity ^0.8.30;

contract PBACContract {

    address public controller;
    uint256 public lastPolicyId;

    enum PolicyKind {
        Emergency,
        Normal,
        Delegate
    }

    enum AccessLevel {
        None,
        Partial,
        Full
    }

    enum ConsentStatus {
        Pending,
        Granted,
        Denied,
        PartialGranted
    }

    enum DenialReason {
        None,
        PurposeMismatch,
        AccessLevelTooHigh,
        ConsentNotGranted,
        PolicyInactive,
        PolicyDisabled,
        PolicyExpired,
        PolicyRevoked,
        PatientDoesNotExist,
        NeedApproval,
        DiagnosisMismatch,
        NoActivePolicy
    }

    struct PatientRecord {
        uint256 patientId;
        address patientAddress;
        address delegateAddress;
        bool exists;

        string diagnosis;

        // Off-chain IPFS references
        string partialCid;
        bytes32 partialHash;

        string fullCid;
        bytes32 fullHash;

        uint256 activePolicyId;
    }

    struct Policy {
        uint256 policyId;
        uint256 patientId;

        PolicyKind kind;
        AccessLevel access;

        string diagnosis;
        string purpose;

        bool isActive;
        bool isEnabled;
        bool consent;
        bool revoked;

        address creator;

        uint256 validFrom;
        uint256 validUntil;
    }

    struct AccessRequest {
        uint256 requestId;
        address requester;
        uint256 patientId;

        string diagnosis;
        string purpose;
        AccessLevel requestedAccess;

        // Optional IPFS reference for external request document,
        // such as research proposal, approval letter, or justification.
        string requestCid;
        bytes32 requestHash;

        ConsentStatus status;
        DenialReason reason;

        uint256 policyIdAtRequest;
        uint256 timestamp;
    }

    mapping(uint256 => PatientRecord) public patientRecords;
    mapping(uint256 => Policy) public policies;
    mapping(uint256 => AccessRequest) public accessRequests;

    // Optional helper mapping for demo lookup.
    // In real multi-patient same-diagnosis cases, do not depend on diagnosis alone.
    mapping(bytes32 => uint256) public diagnosisToPatientId;

    event PatientRecordRegistered(
        uint256 indexed patientId,
        address indexed patientAddress,
        string diagnosis,
        string partialCid,
        string fullCid
    );

    event PolicyCreated(
        uint256 indexed policyId,
        uint256 indexed patientId,
        PolicyKind kind,
        AccessLevel access,
        string purpose,
        bool consent,
        uint256 validFrom,
        uint256 validUntil
    );

    event ConsentUpdated(
        uint256 indexed policyId,
        bool consent
    );

    event PolicyRevoked(
        uint256 indexed policyId
    );

    event AccessRequested(
        uint256 indexed requestId,
        uint256 indexed patientId,
        address indexed requester,
        string purpose,
        AccessLevel requestedAccess
    );

    event AccessGranted(
        uint256 indexed requestId,
        string cid,
        bytes32 recordHash
    );

    event PartialAccessGranted(
        uint256 indexed requestId,
        string cid,
        bytes32 recordHash
    );

    event AccessDenied(
        uint256 indexed requestId,
        DenialReason reason
    );

    event PendingRequest(
        uint256 indexed requestId,
        DenialReason reason
    );

    modifier onlyController() {
        require(msg.sender == controller, "Only controller");
        _;
    }

    constructor() public {
        controller = msg.sender;
    }

    // ============================================================
    // Algorithm 1:
    // Patient Registration + IPFS Reference Storage
    // ============================================================

    function registerPatientRecord(
        uint256 patientId,
        address patientAddress,
        address delegateAddress,
        string memory diagnosis,
        string memory partialCid,
        bytes32 partialHash,
        string memory fullCid,
        bytes32 fullHash
    ) external onlyController {

        require(patientId != 0, "Invalid patientId");
        require(patientAddress != address(0), "Invalid patient address");
        require(!patientRecords[patientId].exists, "Patient already exists");

        require(bytes(diagnosis).length > 0, "Diagnosis required");

        require(bytes(partialCid).length > 0, "Partial CID required");
        require(bytes(fullCid).length > 0, "Full CID required");

        require(partialHash != bytes32(0), "Partial hash required");
        require(fullHash != bytes32(0), "Full hash required");

        patientRecords[patientId] = PatientRecord({
            patientId: patientId,
            patientAddress: patientAddress,
            delegateAddress: delegateAddress,
            exists: true,
            diagnosis: diagnosis,
            partialCid: partialCid,
            partialHash: partialHash,
            fullCid: fullCid,
            fullHash: fullHash,
            activePolicyId: 0
        });

        diagnosisToPatientId[keccak256(bytes(diagnosis))] = patientId;

        emit PatientRecordRegistered(
            patientId,
            patientAddress,
            diagnosis,
            partialCid,
            fullCid
        );
    }

    // ============================================================
    // Algorithm 2:
    // On-chain Consent-Policy Registration
    // ============================================================

    function createPolicy(
        uint256 patientId,
        PolicyKind kind,
        AccessLevel access,
        string memory purpose,
        uint256 duration,
        bool initialConsent
    ) external returns (uint256) {

        PatientRecord storage patient = patientRecords[patientId];

        require(patient.exists, "Patient does not exist");
        require(bytes(purpose).length > 0, "Purpose required");
        require(duration > 0, "Duration must be positive");

        if (kind == PolicyKind.Normal) {
            require(
                msg.sender == patient.patientAddress ||
                msg.sender == controller,
                "Not authorized for normal policy"
            );
        } else if (kind == PolicyKind.Delegate) {
            require(patient.delegateAddress != address(0), "No delegate assigned");
            require(
                msg.sender == patient.delegateAddress ||
                msg.sender == controller,
                "Not authorized for delegate policy"
            );
        } else if (kind == PolicyKind.Emergency) {
            require(msg.sender == controller, "Only controller can create emergency policy");
        }

        uint256 policyId = ++lastPolicyId;

        uint256 startTime = block.timestamp;
        uint256 endTime = startTime + duration;

        policies[policyId] = Policy({
            policyId: policyId,
            patientId: patientId,
            kind: kind,
            access: access,
            diagnosis: patient.diagnosis,
            purpose: purpose,
            isActive: true,
            isEnabled: true,
            consent: initialConsent,
            revoked: false,
            creator: msg.sender,
            validFrom: startTime,
            validUntil: endTime
        });

        patient.activePolicyId = policyId;

        emit PolicyCreated(
            policyId,
            patientId,
            kind,
            access,
            purpose,
            initialConsent,
            startTime,
            endTime
        );

        return policyId;
    }

    function updateConsent(
        uint256 policyId,
        bool newConsent
    ) external {

        Policy storage policy = policies[policyId];

        require(policy.policyId != 0, "Policy does not exist");
        require(_canManagePolicy(policy), "Not authorized");
        require(!policy.revoked, "Policy revoked");

        policy.consent = newConsent;

        emit ConsentUpdated(policyId, newConsent);
    }

    function revokePolicy(
        uint256 policyId
    ) external {

        Policy storage policy = policies[policyId];

        require(policy.policyId != 0, "Policy does not exist");
        require(_canManagePolicy(policy), "Not authorized");

        policy.revoked = true;
        policy.isActive = false;
        policy.consent = false;

        emit PolicyRevoked(policyId);
    }

    function enablePolicy(
        uint256 policyId
    ) external {

        Policy storage policy = policies[policyId];

        require(policy.policyId != 0, "Policy does not exist");
        require(_canManagePolicy(policy), "Not authorized");
        require(!policy.revoked, "Policy revoked");

        policy.isEnabled = true;
    }

    function disablePolicy(
        uint256 policyId
    ) external {

        Policy storage policy = policies[policyId];

        require(policy.policyId != 0, "Policy does not exist");
        require(_canManagePolicy(policy), "Not authorized");

        policy.isEnabled = false;
    }

    // ============================================================
    // Algorithm 3:
    // Requester Access Request
    // Core request fields are stored on-chain.
    // Optional request document is referenced through IPFS CID/hash.
    // ============================================================

    function submitAccessRequest(
        uint256 requestId,
        uint256 patientId,
        string memory diagnosis,
        string memory purpose,
        AccessLevel requestedAccess,
        string memory requestCid,
        bytes32 requestHash
    ) external {

        require(requestId != 0, "Invalid requestId");
        require(accessRequests[requestId].timestamp == 0, "Request already exists");

        require(bytes(diagnosis).length > 0, "Diagnosis required");
        require(bytes(purpose).length > 0, "Purpose required");

        PatientRecord storage patient = patientRecords[patientId];

        require(patient.exists, "Patient does not exist");
        require(patient.activePolicyId != 0, "No active policy");

        accessRequests[requestId] = AccessRequest({
            requestId: requestId,
            requester: msg.sender,
            patientId: patientId,
            diagnosis: diagnosis,
            purpose: purpose,
            requestedAccess: requestedAccess,
            requestCid: requestCid,
            requestHash: requestHash,
            status: ConsentStatus.Pending,
            reason: DenialReason.None,
            policyIdAtRequest: patient.activePolicyId,
            timestamp: block.timestamp
        });

        emit AccessRequested(
            requestId,
            patientId,
            msg.sender,
            purpose,
            requestedAccess
        );
    }

    // ============================================================
    // Algorithm 4:
    // PBAC Policy Decision Module
    // Evaluates active policy against requester request.
    // ============================================================

    function evaluateRequest(
        uint256 requestId
    ) public {

        AccessRequest storage requestData = accessRequests[requestId];

        require(requestData.timestamp != 0, "Request does not exist");

        PatientRecord storage patient = patientRecords[requestData.patientId];

        if (!patient.exists) {
            requestData.status = ConsentStatus.Denied;
            requestData.reason = DenialReason.PatientDoesNotExist;
            emit AccessDenied(requestId, DenialReason.PatientDoesNotExist);
            return;
        }

        Policy storage policy = policies[requestData.policyIdAtRequest];

        DenialReason checkResult = _checkPolicyAgainstRequest(requestData, policy);

        if (checkResult != DenialReason.None) {
            requestData.status = ConsentStatus.Denied;
            requestData.reason = checkResult;
            emit AccessDenied(requestId, checkResult);
            return;
        }

        if (!policy.consent) {
            requestData.status = ConsentStatus.Pending;
            requestData.reason = DenialReason.NeedApproval;
            emit PendingRequest(requestId, DenialReason.NeedApproval);
            return;
        }

        if (
            policy.access == AccessLevel.Partial ||
            requestData.requestedAccess == AccessLevel.Partial
        ) {
            requestData.status = ConsentStatus.PartialGranted;
            requestData.reason = DenialReason.None;

            emit PartialAccessGranted(
                requestId,
                patient.partialCid,
                patient.partialHash
            );
        } else {
            requestData.status = ConsentStatus.Granted;
            requestData.reason = DenialReason.None;

            emit AccessGranted(
                requestId,
                patient.fullCid,
                patient.fullHash
            );
        }
    }

    // Patient / controller / delegate can approve pending request by updating policy consent
    // and re-running the PBAC decision.
    function approvePendingRequest(
        uint256 requestId
    ) external {

        AccessRequest storage requestData = accessRequests[requestId];

        require(requestData.timestamp != 0, "Request does not exist");

        Policy storage policy = policies[requestData.policyIdAtRequest];

        require(_canManagePolicy(policy), "Not authorized");

        policy.consent = true;

        emit ConsentUpdated(policy.policyId, true);

        evaluateRequest(requestId);
    }

    function denyPendingRequest(
        uint256 requestId
    ) external {

        AccessRequest storage requestData = accessRequests[requestId];

        require(requestData.timestamp != 0, "Request does not exist");

        Policy storage policy = policies[requestData.policyIdAtRequest];

        require(_canManagePolicy(policy), "Not authorized");

        requestData.status = ConsentStatus.Denied;
        requestData.reason = DenialReason.ConsentNotGranted;

        emit AccessDenied(requestId, DenialReason.ConsentNotGranted);
    }

    // ============================================================
    // Result query for requester
    // ============================================================

    function statusByRequester(
        uint256 requestId
    ) external view returns (
        ConsentStatus status,
        DenialReason reason,
        uint256 policyId,
        string memory policyPurpose,
        string memory resultCid,
        bytes32 resultHash
    ) {

        AccessRequest storage requestData = accessRequests[requestId];

        require(requestData.timestamp != 0, "Request does not exist");
        require(requestData.requester == msg.sender, "Only requester can check");

        PatientRecord storage patient = patientRecords[requestData.patientId];
        Policy storage policy = policies[requestData.policyIdAtRequest];

        status = requestData.status;
        reason = requestData.reason;
        policyId = requestData.policyIdAtRequest;
        policyPurpose = policy.purpose;

        if (requestData.status == ConsentStatus.PartialGranted) {
            resultCid = patient.partialCid;
            resultHash = patient.partialHash;
        } else if (requestData.status == ConsentStatus.Granted) {
            resultCid = patient.fullCid;
            resultHash = patient.fullHash;
        } else {
            resultCid = "";
            resultHash = bytes32(0);
        }
    }

    // ============================================================
    // Metadata views
    // ============================================================

    function getPatientRecordMetadata(
        uint256 patientId
    ) external view returns (
        address patientAddress,
        address delegateAddress,
        bool exists,
        string memory diagnosis,
        uint256 activePolicyId
    ) {

        PatientRecord storage patient = patientRecords[patientId];

        return (
            patient.patientAddress,
            patient.delegateAddress,
            patient.exists,
            patient.diagnosis,
            patient.activePolicyId
        );
    }

    function getPolicyDetails(
        uint256 policyId
    ) external view returns (
        uint256 patientId,
        PolicyKind kind,
        AccessLevel access,
        string memory diagnosis,
        string memory purpose,
        bool isActive,
        bool isEnabled,
        bool consent,
        bool revoked,
        address creator,
        uint256 validFrom,
        uint256 validUntil
    ) {

        Policy storage policy = policies[policyId];

        require(policy.policyId != 0, "Policy does not exist");

        return (
            policy.patientId,
            policy.kind,
            policy.access,
            policy.diagnosis,
            policy.purpose,
            policy.isActive,
            policy.isEnabled,
            policy.consent,
            policy.revoked,
            policy.creator,
            policy.validFrom,
            policy.validUntil
        );
    }

    function getRequestDetails(
        uint256 requestId
    ) external view returns (
        address requester,
        uint256 patientId,
        string memory diagnosis,
        string memory purpose,
        AccessLevel requestedAccess,
        ConsentStatus status,
        DenialReason reason,
        uint256 policyIdAtRequest,
        uint256 timestamp,
        string memory requestCid,
        bytes32 requestHash
    ) {

        AccessRequest storage requestData = accessRequests[requestId];

        require(requestData.timestamp != 0, "Request does not exist");

        return (
            requestData.requester,
            requestData.patientId,
            requestData.diagnosis,
            requestData.purpose,
            requestData.requestedAccess,
            requestData.status,
            requestData.reason,
            requestData.policyIdAtRequest,
            requestData.timestamp,
            requestData.requestCid,
            requestData.requestHash
        );
    }

    function policyCount() external view returns (uint256) {
        return lastPolicyId;
    }

    // ============================================================
    // Internal PBAC checking logic
    // ============================================================

    function _checkPolicyAgainstRequest(
        AccessRequest memory requestData,
        Policy memory policy
    ) internal view returns (DenialReason) {

        if (policy.policyId == 0) {
            return DenialReason.NoActivePolicy;
        }

        if (!policy.isActive) {
            return DenialReason.PolicyInactive;
        }

        if (!policy.isEnabled) {
            return DenialReason.PolicyDisabled;
        }

        if (policy.revoked) {
            return DenialReason.PolicyRevoked;
        }

        if (block.timestamp > policy.validUntil) {
            return DenialReason.PolicyExpired;
        }

        if (
            keccak256(bytes(requestData.diagnosis)) !=
            keccak256(bytes(policy.diagnosis))
        ) {
            return DenialReason.DiagnosisMismatch;
        }

        if (
            keccak256(bytes(requestData.purpose)) !=
            keccak256(bytes(policy.purpose))
        ) {
            return DenialReason.PurposeMismatch;
        }

        if (
            uint8(requestData.requestedAccess) >
            uint8(policy.access)
        ) {
            return DenialReason.AccessLevelTooHigh;
        }

        return DenialReason.None;
    }

    function _canManagePolicy(
        Policy memory policy
    ) internal view returns (bool) {

        PatientRecord storage patient = patientRecords[policy.patientId];

        if (msg.sender == controller) {
            return true;
        }

        if (msg.sender == patient.patientAddress) {
            return true;
        }

        if (msg.sender == policy.creator) {
            return true;
        }

        if (
            policy.kind == PolicyKind.Delegate &&
            msg.sender == patient.delegateAddress
        ) {
            return true;
        }

        return false;
    }
}